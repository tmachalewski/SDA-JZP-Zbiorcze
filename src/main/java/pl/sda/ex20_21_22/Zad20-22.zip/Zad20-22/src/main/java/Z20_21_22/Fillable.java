package Z20_21_22;

//zad.22
public interface Fillable {
    void fill(int filler);
}
