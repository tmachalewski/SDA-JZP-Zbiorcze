package Z20_21_22;

//zad.20
public abstract class Shape {
    public abstract double calculatePerimeter();//obliczanie obwodu
    public abstract double calculateArea(); //obliczanie powierzchni

}
