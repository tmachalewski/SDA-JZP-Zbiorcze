package Z20_21_22;

//zad.21
public abstract class Shape3D extends Shape {
    public abstract double calculateVolume();
}
